font_size=34
heading_font_size=38
number_of_file=15
max_width_to_search=1790
draw_gaze=False