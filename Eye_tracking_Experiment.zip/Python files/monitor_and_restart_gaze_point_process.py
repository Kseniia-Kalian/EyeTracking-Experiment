import psutil
import os
import datetime
from subprocess import call
import time

while True:
    if "Interaction_Streams_102.exe" in (p.name() for p in psutil.process_iter()):
        pass
    else:
        dir = r'D:\\eyetracker\\Eye tracking Experiment\\EyeTracking_GazeLogger'
        # os.chdir(dir)
        # print(os.getcwd())
        # print(os.listdir())
        cmdline = "Interaction_Streams_102.exe"
        rc = call("start cmd /K " + cmdline, cwd=dir, shell=True)
        print('Program was restarted', datetime.datetime.now())
        time.sleep(1)
