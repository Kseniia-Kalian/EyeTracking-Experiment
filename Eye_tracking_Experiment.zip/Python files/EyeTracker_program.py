
#Download eye tracker manager: https://www.tobiipro.com/learn-and-support/downloads-pro/
#download wython 3.5.4 :  https://www.python.org/downloads/release/python-354/


import  time, os, sys
from config import *

'''
a = 'pip install pygame'
os.system(a)
a = 'pip install tobii_research'
os.system(a)
a = 'pip install psutil'
os.system(a)
'''

import psutil
#import pygaze
import sys
import pygame as pg
import tobii_research as tr

def main():
    ################################################################################
    #Parameters:
    ################################################################################
    amount_of_texts = number_of_file #how many text samples

    path_TobiiProEyeTrackerManager = 'C:\\Users\\kseni\\AppData\\Local\\Programs\\TobiiProEyeTrackerManager\\'
    #Main font
    font = pg.font.SysFont(("Arial"), font_size)
    font_heading = pg.font.SysFont(("Arial"), heading_font_size)
    font_color = (0, 0, 0)
    fnt_background = (255, 255, 255)

    #translation font
    font_color_translation = (0, 0, 0)
    fnt_background_translation = (244,231,176)

    #translation border settings
    translation_border_line_color = (11, 170, 60)
    translation_border_size_width = 10
    translation_border_size_height = 2
    translation_border_line_thickness = 3

    #Gaze settings:
    buttons_left, buttons_top = 1600, 900

    #default gaze activation times
    gaze_activation_time = 0.5
    gaze_deactivation_time = 0.5 

    #Gaze settings font
    font_gaze_settings = pg.font.SysFont(("Arial"), 20)

    #other parameters
    screen_background_color = (255, 255, 255)
    lineSpacing = font.size("Tg")[1] + 0
    left = 60 #where textbox starts from left
    top  = 130 #where textbox starts from top
    aa = True #Anti-aliasing (makes pixelated lines look better)
    wrap_max = max_width_to_search  # max width (text wrapping)

    ################################################################################
    #Program start:
    ################################################################################

    gaze_coords_lod = []

    ################################################################################
    # Eyetracker stuff
    ################################################################################

    found_eyetrackers = tr.find_all_eyetrackers()
    my_eyetracker = found_eyetrackers[0]
    print()
    print('Eye tracker info:')
    print("Address: " + my_eyetracker.address)
    print("Model: " + my_eyetracker.model)
    print("Name (It's OK if this is empty): " + my_eyetracker.device_name)
    print("Serial number: " + my_eyetracker.serial_number)

    # os.system(path_TobiiProEyeTrackerManager + 'TobiiProEyeTrackerManager.exe --mode=usercalibration --device-sn={}'.format(my_eyetracker.serial_number))




    #initialize
    info = pg.display.Info()
    screen = pg.display.set_mode((info.current_w, info.current_h), pg.FULLSCREEN)
    screen_rect = screen.get_rect()

    # # Open a window on the screen #TODO: Remove for Kseniia
    # screen_width = 1920
    # screen_height = 1080
    # screen = pg.display.set_mode([screen_width, screen_height])

    #some calculated parameters
    s_width, s_height = font.size(' ') #dimensions of a space/blank character



    ################################################################################
    #Get texts from disk - add to 3 lists
    ################################################################################
    texts = []
    special_words = []
    headings = []

    for text_number in range(1,amount_of_texts+1):
        #get heading
        with open('text{} heading.txt'.format(text_number), 'r', encoding='utf-8') as file:
            heading = file.read()
        #get text
        with open('text{}.txt'.format(text_number), 'r', encoding='utf-8') as file:
            text = file.read()
            text = text.replace('\n', ' newline_here ')  # We make newlines ourselves. Pygame doesn't play nice with newlines. Note spaces.
            #get special words
        list_of_dict_spcwords = []
        with open('text{} special words.txt'.format(text_number), 'r', encoding='utf-8') as file:
            input = file.read().splitlines()
            for line in input:
                word = line.split('=')[0]
                trans = line.split('=')[-1]
                bbox = () #bounding box of word as displayed
                tmp = {'word': word, 'trans': trans, 'bbox': bbox, 'previous_gaze_activation_time': 0}
                list_of_dict_spcwords.append(tmp)

        texts.append(text)
        special_words.append(list_of_dict_spcwords)
        headings.append(heading)

    #initialize with text 1:
    current_text_number = 1

    ################################################################################
    #Main loop
    ################################################################################

    done = False
    prev_time = time.time() #measure fps
    time.sleep(0.1) #or fps measure fails
    while not done:
        print('fps = ', 1/(time.time() - prev_time))
        prev_time = time.time()  # measure fps
        for event in pg.event.get():
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_ESCAPE:
                    done = True
                #GOTO NEXT/PREV TEXT:
                if event.key ==pg.K_RIGHT:
                    current_text_number = min(current_text_number+1, amount_of_texts)
                if event.key == pg.K_LEFT:
                    current_text_number = max(current_text_number-1, 1)

        #GOTO NEXT/PREV TEXT:
        text = texts[current_text_number - 1]
        heading = headings[current_text_number - 1]
        list_of_dict_spcwords = special_words[current_text_number - 1]

        #initialize screen
        screen.fill(screen_background_color)

        ################################################################################
        #Add gaze settings buttons
        ################################################################################
        black = (0,0,0)
        gray = (150,150,150)
        def text_objects(text, font):
            textSurface = font.render(text, True, black)
            return textSurface, textSurface.get_rect()
        def button(msg, x, y, w, h, ic, ac, action=None):
            gaze_activation_change = 0
            mouse = pg.mouse.get_pos()
            click = pg.mouse.get_pressed()
            if x + w > mouse[0] > x and y + h > mouse[1] > y:
                pg.draw.rect(screen, ac, (x, y, w, h), 2)
                if click[0] == 1: #left click
                    if action == 'increment_activation':
                        gaze_activation_change = 0.1
                    if action == 'decrement_activation':
                        gaze_activation_change = -0.1
                    time.sleep(0.1) #To avoid to fast changes
            else:
                pg.draw.rect(screen, ic, (x, y, w, h), 2)
            smallText = pg.font.SysFont("Calibri", 20)
            textSurf, textRect = text_objects(msg, smallText)
            textRect.center = ((x + (w / 2)), (y + (h / 2)))
            screen.blit(textSurf, textRect)
            return gaze_activation_change

        #BUTTON AND TEXT FOR: gaze_activation_time
        x_adjust_for_activation = 500
        gaze_activation_time += button("Increase",buttons_left - x_adjust_for_activation,buttons_top + 120,100,50,black,gray, 'increment_activation')
        gaze_activation_time += button("Decrease",buttons_left+120 - x_adjust_for_activation ,buttons_top + 120,100,50,black,gray, 'decrement_activation')
        #text
        text_gaze_activation_time = 'Gaze activation time = {} seconds'.format(round(gaze_activation_time,1))
        rendered = font_gaze_settings.render(text_gaze_activation_time, aa, font_color, fnt_background)
        pos = (buttons_left - x_adjust_for_activation, buttons_top - 30 + 120)
        screen.blit(rendered, pos)

        #BUTTON AND TEXT FOR: gaze_deactivation_time
        y_gap_beween_buttongroups = 120
        gaze_deactivation_time += button("Increase",buttons_left,buttons_top + y_gap_beween_buttongroups,100,50,black,gray, 'increment_activation')
        gaze_deactivation_time += button("Decrease",buttons_left+120,buttons_top + y_gap_beween_buttongroups, 100,50,black,gray, 'decrement_activation')
        #text
        text_gaze_activation_time = 'Gaze inactivation time = {} seconds'.format(round(gaze_deactivation_time,1))
        rendered = font_gaze_settings.render(text_gaze_activation_time, aa, font_color, fnt_background)
        pos = (buttons_left, buttons_top - 30 + y_gap_beween_buttongroups)
        screen.blit(rendered, pos)

        ################################################################################
        #Draw words
        ################################################################################

        #Draw heading
        rendered = font_heading.render(heading, aa, font_color, fnt_background)
        pos = (left, top - font_heading.size(heading)[1] - 20)
        screen.blit(rendered, pos)

        #Draw all words, and populate list_of_dict_spcwords bboxes
        current_x = 0
        current_y = 0
        for word in text.split(' '):
            #We make newlines ourselves. Pygame doesn't play nice with newlines
            if 'newline_here' in word:
                current_y += lineSpacing
                current_x = 0
                continue #goto next word

            text_width, text_height = font.size(word)

            #start on new line if wrap_max is reached
            if current_x + text_width > wrap_max:
                current_x = 0
                current_y += lineSpacing

            #check for special word
            is_special_word = False
            for d in list_of_dict_spcwords:
                if d['word'].lower().replace(':','').replace(',','').replace('!','').replace('.','') == word.lower().replace(':','').replace(',','').replace('!','').replace('.',''):
                    is_special_word = True
                    d['bbox'] = (current_x + left, current_y + top, text_width+10, text_height+10)
            if is_special_word:
                font.set_underline(True)
            else:
                font.set_underline(False)


            rendered = font.render(word, aa, font_color, fnt_background)
            pos = (current_x + left, current_y + top)
            screen.blit(rendered,pos)

            #increment current_x
            current_x += text_width + s_width

        ################################################################################
        #Get Gaze/eye tracker data
        ################################################################################

        def get_current_gazepoint():
            fname = 'D:\\eyetracker\\Eye tracking Experiment\\EyeTracking_GazeLogger\\data.txt' #todo
            # fail mode 1
            if not os.path.isfile(fname):
                return 0,0,0

            with open(fname, 'r') as f:
                lines = f.read().splitlines()
                #fail mode 2
                if len(lines) == 0:
                    return 0,0,0

                last_line = lines[-1]
            data = last_line.split(' ')
            tsgaze = float(int(data[0])/1000) #unix time in milliseconds. converted so that it is equivalent to pythons time.time()
            if ',' in data[1]:
                xgaze = int(data[1].split(',')[0])
                ygaze = int(data[2].split(',')[0])
            else:
                xgaze = int(data[1].split('.')[0])
                ygaze = int(data[2].split('.')[0])
            return tsgaze, xgaze, ygaze

        tsgaze, xgaze, ygaze = get_current_gazepoint()


        #Draw gaze rectangle:
        if draw_gaze:
            gaze_color = (255,200,50)
            gaze_rect_coord = (xgaze, ygaze, 20, 20)
            pg.draw.rect(screen, gaze_color, gaze_rect_coord, 4)


        ################################################################################
        #Draw translation words: Check if mouse or gaze hovers on special word
        ################################################################################
        ms_x, ms_y = pg.mouse.get_pos()

        def rectContains(rect, pt):
            isInside = rect[0] < pt[0] < rect[0] + rect[2] and rect[1] < pt[1] < rect[1] + rect[3]
            return isInside

        def isGazeInside_function(rect,pt):
            # rect = (current_x + left, current_y + top, text_width, text_height)
            rect_x, rect_y, rect_width, rect_height = rect[0], rect[1], rect[2], rect[3]
            #adjust y point up, and make 3* higher height
            rect_y = rect_y - rect_height  # raise box up
            rect_height = int(rect_height*3.5)

            #make width area slightly larger
            rect_x = rect_x - 7
            rect_width = rect_width + 14

            #reassign rectangle
            rect = (rect_x, rect_y, rect_width, rect_height)
            isInside = rect[0] < pt[0] < rect[0] + rect[2] and rect[1] < pt[1] < rect[1] + rect[3]
            return isInside

        #remove any too old gazeCoords, and add the new datapoint:
        new_list = []
        for dict in gaze_coords_lod:
            if dict['ts'] > time.time() - gaze_activation_time:
                new_list.append(dict)
        tmp = {}
        tmp['ts'] = tsgaze
        tmp['x'] = xgaze
        tmp['y'] = ygaze
        new_list.append(tmp)
        gaze_coords_lod = new_list

        for d in list_of_dict_spcwords:
            #is gaze upon this special word?
            #has the previous x seconds all been inside?
            all_was_inside = True
            for dict in gaze_coords_lod:
                isGazeInside = isGazeInside_function(d['bbox'], (dict['x'], dict['y']))
                if not isGazeInside:
                    all_was_inside = False

            #keep track of when this word was no longer looked at
            if all_was_inside:
                d['previous_gaze_activation_time'] = time.time()
            #show the word up to gaze_deactivation_time after looking away
            show_trans_due_to_deactivation_time = time.time() - d['previous_gaze_activation_time'] < gaze_deactivation_time

            isMouseInside = rectContains(d['bbox'], (ms_x, ms_y))
            if isMouseInside or all_was_inside or show_trans_due_to_deactivation_time:
                #Render and calc pos of translation below word - blipped lastly
                font.set_italic(False)
                rendered_translation_text = font.render(d['trans'], aa, font_color_translation, fnt_background_translation)
                font.set_italic(False)
                trans_text_width, trans_text_height = font.size(d['trans'])
                special_word_width, special_word_height = font.size(d['word'])
                x,y,width,height = d['bbox']
                y = y + lineSpacing + 10 #draw below word
                x = x + int((special_word_width/2) - (trans_text_width/2)) #Have translation centered above word
                pos_translation_text = (x,y,width,height)


                #1: box background (Using many of the coords calculated above!)
                #Render and calc pos of box, for border around translation text
                rekt_color = fnt_background_translation
                rect_coord = x-translation_border_size_width,y-translation_border_size_height,trans_text_width + translation_border_size_width*2,trans_text_height +translation_border_size_height*2
                box_width = 0
                pg.draw.rect(screen, rekt_color, rect_coord, box_width)


                #2: box border
                #Render and calc pos of box, for border around translation text
                rekt_color = translation_border_line_color
                rect_coord = x-translation_border_size_width,y-translation_border_size_height,trans_text_width + translation_border_size_width*2,trans_text_height +translation_border_size_height*2
                pg.draw.rect(screen, rekt_color, rect_coord, translation_border_line_thickness)


                #Blit text to screen lastly
                screen.blit(rendered_translation_text , pos_translation_text)

        #update display
        pg.display.flip()



if __name__ == '__main__':
    pg.init()
    main()
    pg.quit()
    sys.exit()





















